// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#include <iostream>
#include <tchar.h>
#include <minmax.h>
//atlcoll is for arrays
//#include <atlcoll.h>
//atlstr is for atl string functions
//#include <atlstr.h>
// TODO: reference additional headers your program requires here
